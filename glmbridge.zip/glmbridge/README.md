# GlmBridge — let the AI in the chat drive your Roblox Studio

GlmBridge connects an AI agent (GLM in your chat) **directly** to Roblox Studio.
No browser extension, no command dialect — the agent talks straight to Studio's
built-in MCP server through a small relay you run on your PC.

```
AI agent (chat)  ──HTTPS──>  cloudflared tunnel  ──>  glmrelay.py (your PC)  ──MCP──>  Roblox Studio
```

## Setup (first time, ~3 minutes)

### 1. Enable Studio's MCP server (one-time toggle)

1. Open **Roblox Studio** and load any Place.
2. Click **Assistant AI** in the top bar.
3. Click the **...** (top-right of the Assistant panel) → **Manage MCP Servers**.
4. Click **Enable Studio as MCP Server**.

### 2. Run GlmBridge

1. Make sure Python 3 is installed ([python.org](https://www.python.org/downloads/) — tick "Add python.exe to PATH").
2. Double-click **`START_HERE.bat`**.
3. Wait for the line that says:

   ```
   PUBLIC URL:  https://something.trycloudflare.com
   ```

   (The first run downloads `cloudflared.exe` automatically, ~20 MB.)

### 3. Paste the URL into the chat

Send the agent the `https://....trycloudflare.com` URL. It will check
`/status`, list your Studio's tools, and start building with you.

> Keep the relay window open while you're working. Closing it (Ctrl+C) kills
> both the relay and the tunnel URL.

## What the agent can do once connected

Everything Studio's MCP server exposes — typically:

- **`execute_luau`** — run Luau in Edit / Client / Server context (build parts,
  tween, spawn, edit terrain, ...)
- **inspect / search the game tree** — see every Instance and its properties
- **read & write scripts** — view source, rewrite, create/delete scripts
- **play-test control** — start/stop play sessions, read output/errors
- **Creator Store** — search and insert free models/meshes/audio

The exact live list (with parameter schemas) is always at `GET /tools`
and on the status page — open the URL in your browser to see it.

## Files

| File | What it is |
|---|---|
| `glmrelay.py` | The relay: HTTP ⇄ MCP, StudioMCP discovery, tunnel manager |
| `START_HERE.bat` | One-click launcher (relay + tunnel in one window) |
| `glm_agent.py` | Agent-side client; also usable manually (`python glm_agent.py tools <URL>`) |

## Endpoints (for the curious)

- `GET /` — status page (green dot = Studio connected)
- `GET /status` — JSON state (MCP alive, tool count, tunnel URL)
- `GET /tools` — live tool list with JSON schemas
- `POST /call` — `{"tool": "...", "arguments": {...}, "timeout": 60}`

## Safety — read once

- You chose **no token auth**: the tunnel URL is random and unguessable, but
  *anyone who has it can run code in your Studio*. Don't post it publicly,
  and close the relay when you're done. (A token check is a 10-line add if
  you ever change your mind.)
- Tool calls run real Luau in your open Place. Save your work before big
  experiments — Ctrl+Z in Studio undoes agent edits too.
- Quick-tunnel URLs rotate every restart. That's normal; just paste the new one.

## Troubleshooting

| Symptom | Fix |
|---|---|
| Status page says `StudioMCP.exe not found` | Open Roblox Studio once, then restart the relay. Studio must be installed normally (per-user install puts it in `%LOCALAPPDATA%\Roblox\Versions`). |
| `0 tools` / warning about "Enable Studio as MCP Server" | Do step 1 above, then restart `START_HERE.bat`. |
| `tunnel: failed to connect` | Your network may block QUIC — it auto-falls-back; if it still fails, run `cloudflared tunnel --url http://localhost:8510 --protocol http2` manually in a second window and keep relay without `--tunnel`. |
| Calls fail with "no Studio instance connected" | Studio's proxy blipped; the relay auto-retries once. If persistent, re-open the Place. |
| Port 8510 busy | Set another port: `set GLM_RELAY_PORT=8511` before running, or edit `glmrelay.py`. |
