@echo off
title GlmBridge - Roblox Studio relay
cd /d "%~dp0"
setlocal

rem ── find a Python 3 interpreter ──────────────────────────────────────────
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY (
  echo.
  echo  [GlmBridge] Python 3 was not found on this PC.
  echo  Install it from https://www.python.org/downloads/
  echo  ^(tick "Add python.exe to PATH" in the installer^), then run this file again.
  echo.
  pause
  exit /b 1
)

rem ── run the relay + tunnel (one process, one window) ─────────────────────
%PY% glmrelay.py --tunnel

echo.
echo  [GlmBridge] stopped.
pause
