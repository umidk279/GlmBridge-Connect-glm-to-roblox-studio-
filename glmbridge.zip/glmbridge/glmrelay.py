#!/usr/bin/env python3
# glmrelay.py - GlmBridge: HTTP <-> Roblox Studio MCP relay
# ─────────────────────────────────────────────────────────────────────────────
# Connects an AI agent (e.g. GLM in a chat sandbox) to YOUR Roblox Studio.
#
#   [AI agent] --HTTPS--> [cloudflared tunnel] --> [glmrelay.py :8510]
#                                                     |--MCP/stdio--> StudioMCP.exe
#                                                                     |--ws--> Roblox Studio
#
# Run modes:
#   python glmrelay.py            relay only (localhost)
#   python glmrelay.py --tunnel   relay + cloudflared quick tunnel (prints public URL)
#
# HTTP API:
#   GET  /          status page (HTML)
#   GET  /status    JSON: relay + MCP connection state
#   GET  /tools     JSON: live tool list from Studio's MCP server
#   POST /call      JSON body {"tool": name, "arguments": {...}, "timeout": sec}
#
# Requirements: Python 3.9+ (stdlib only). cloudflared.exe is auto-downloaded
# for --tunnel mode if not on PATH. No token auth by design (owner's choice):
# the quick-tunnel URL is random and unguessable - keep it private.
# ─────────────────────────────────────────────────────────────────────────────

import json
import os
import queue
import re
import shutil
import subprocess
import sys
import threading
import time
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit
from urllib.request import urlopen

VERSION = "1.0.0"
RELAY_PORT = int(os.environ.get("GLM_RELAY_PORT", "8510"))
HERE = os.path.dirname(os.path.abspath(__file__))
MAX_BODY = 10 * 1024 * 1024
MAX_TEXT = 400_000          # cap tool text responses before truncation note
DEFAULT_TIMEOUT = 120
EXEC_LUAU_TIMEOUT = 30      # Luau runs are kept snappy on purpose
HARD_TIMEOUT_CAP = 300

# Studio's MCP proxy briefly loses its Studio binding now and then; a tool call
# landing in that window fails with one of these even though Studio is open.
TRANSIENT_DROP_HINTS = (
    "no roblox studio instance", "no active studio", "studio instance is connect",
    "studio instance connected", "not connected to", "no studio instance",
)


def log(msg, tag="  "):
    print(f"[{time.strftime('%H:%M:%S')}] {tag} {msg}", flush=True)


# ─────────────────────────────────────────────────────────────────────────────
# StudioMCP.exe discovery: newest version folder that still contains a live
# Studio exe, to avoid zombie installs left behind by Studio auto-updates.
# ─────────────────────────────────────────────────────────────────────────────
ENV_OVERRIDE = "GLM_STUDIO_MCP_PATH"
WIN_STUDIO_EXES = ("RobloxStudioBeta.exe", "RobloxStudio.exe")


def _win_candidate_roots():
    roots = []
    local = os.environ.get("LOCALAPPDATA")
    if local:
        roots.append(os.path.join(local, "Roblox", "Versions"))
    for env in ("ProgramFiles", "ProgramFiles(x86)"):
        v = os.environ.get(env)
        if v:
            roots.append(os.path.join(v, "Roblox", "Versions"))
    return roots


def find_studio_mcp():
    override = os.environ.get(ENV_OVERRIDE)
    if override:
        p = os.path.expandvars(os.path.expanduser(override))
        if os.path.isfile(p):
            return p
        if os.path.isdir(p):
            cand = os.path.join(p, "StudioMCP.exe")
            if os.path.isfile(cand):
                return cand
        log(f"{ENV_OVERRIDE} is set but invalid: {override}", "!!")

    if sys.platform == "darwin":
        homes = ["/Applications", os.path.join(os.path.expanduser("~"), "Applications")]
        for base in homes:
            for app in ("RobloxStudio.app", "Roblox.app", "RobloxStudioBeta.app"):
                exe = os.path.join(base, app, "Contents", "MacOS", "StudioMCP")
                if os.path.isfile(exe):
                    return exe
        return None

    paired, zombies = [], []
    for root in _win_candidate_roots():
        if not os.path.isdir(root):
            continue
        try:
            for name in os.listdir(root):
                vdir = os.path.join(root, name)
                if not os.path.isdir(vdir):
                    continue
                mcp = os.path.join(vdir, "StudioMCP.exe")
                if not os.path.isfile(mcp):
                    continue
                if any(os.path.isfile(os.path.join(vdir, e)) for e in WIN_STUDIO_EXES):
                    paired.append((os.path.getmtime(mcp), mcp))
                else:
                    zombies.append((os.path.getmtime(mcp), mcp))
        except OSError:
            continue
    pool = paired or zombies
    return max(pool)[1] if pool else None


# ─────────────────────────────────────────────────────────────────────────────
# Minimal MCP client over stdio (JSON-RPC 2.0, newline-delimited)
# ─────────────────────────────────────────────────────────────────────────────
class StudioMCP:
    def __init__(self):
        self.proc = None
        self.exe_path = None
        self.tools = []
        self.last_error = None
        self.stderr_tail = deque(maxlen=8)
        self.pending = {}
        self.pend_lock = threading.Lock()
        self.write_lock = threading.Lock()
        self.call_lock = threading.Lock()
        self.req_id = 1
        self.booted = threading.Event()

    # -- lifecycle -----------------------------------------------------------
    def is_alive(self):
        return self.proc is not None and self.proc.poll() is None

    def start(self):
        with self.call_lock:
            self._start_locked()

    def _start_locked(self):
        if self.is_alive():
            return
        exe = find_studio_mcp()
        if not exe:
            raise RuntimeError(
                "StudioMCP.exe not found. Install/repair Roblox Studio and open it "
                "once. (Override with env " + ENV_OVERRIDE + "=path if needed.)")
        self.exe_path = exe
        log(f"launching StudioMCP: {exe}")
        self.proc = subprocess.Popen(
            [exe], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, bufsize=1, encoding="utf-8", errors="replace", cwd=HERE)
        self.stderr_tail.clear()
        self.last_error = None
        threading.Thread(target=self._reader, args=(self.proc,), daemon=True).start()
        threading.Thread(target=self._stderr_drain, args=(self.proc,), daemon=True).start()

        # MCP handshake. StudioMCP attaches to the running Studio a beat AFTER
        # the stdio handshake, so tools/list may be empty at first - retry.
        self._request("initialize", {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {"name": "zerobridge", "version": VERSION},
        }, timeout=30)
        self._notify("notifications/initialized")
        got_tools = False
        for _ in range(12):
            if self.refresh_tools(timeout=3):
                got_tools = True
                break
            if not self.is_alive():
                break
            time.sleep(1.0)
        self.booted.set()
        if not got_tools:
            self.last_error = ("MCP server is up but advertises 0 tools. In Roblox Studio: "
                               "Assistant AI (top bar) > '...' > Manage MCP Servers > "
                               "'Enable Studio as MCP Server'. Then restart this relay.")
        else:
            self.last_error = None
            log(f"MCP up - {len(self.tools)} tools advertised")

    def stop(self):
        with self.pend_lock:
            for q in self.pending.values():
                q.put_nowait(None)
            self.pending.clear()
        if self.proc:
            try:
                if sys.platform == "win32":
                    subprocess.run(["taskkill", "/F", "/T", "/PID", str(self.proc.pid)],
                                   capture_output=True, timeout=8)
                else:
                    self.proc.terminate()
            except Exception:
                pass
        self.proc = None
        self.booted.clear()

    # -- io threads ------------------------------------------------------------
    def _reader(self, proc):
        stream = proc.stdout
        while True:
            try:
                line = stream.readline()
            except Exception:
                break
            if line == "":
                break
            line = line.strip()
            if not line:
                continue
            try:
                msg = json.loads(line)
            except Exception:
                continue
            mid = msg.get("id")
            if mid is None:
                continue
            with self.pend_lock:
                q = self.pending.get(mid)
            if q is not None:
                q.put_nowait(msg)
        code = proc.poll()
        log(f"StudioMCP exited (code {code})", "!!")
        with self.pend_lock:
            for q in self.pending.values():
                q.put_nowait(None)

    def _stderr_drain(self, proc):
        try:
            for line in iter(proc.stderr.readline, ""):
                line = line.rstrip()
                if not line:
                    continue
                self.stderr_tail.append(line)
                log(f"studio-mcp stderr: {line}", "..")
        except Exception:
            pass

    # -- jsonrpc -----------------------------------------------------------------
    def _notify(self, method, params=None):
        payload = {"jsonrpc": "2.0", "method": method, "params": params or {}}
        with self.write_lock:
            self.proc.stdin.write(json.dumps(payload) + "\n")
            self.proc.stdin.flush()

    def _request(self, method, params, timeout):
        if not self.is_alive():
            raise RuntimeError("StudioMCP is not running")
        with self.write_lock:
            rid = self.req_id
            self.req_id += 1
        q = queue.Queue(maxsize=1)
        with self.pend_lock:
            self.pending[rid] = q
        try:
            payload = {"jsonrpc": "2.0", "id": rid, "method": method,
                       "params": params or {}}
            with self.write_lock:
                self.proc.stdin.write(json.dumps(payload) + "\n")
                self.proc.stdin.flush()
            try:
                return q.get(timeout=timeout)
            except queue.Empty:
                return None
        finally:
            with self.pend_lock:
                self.pending.pop(rid, None)

    # -- high level ---------------------------------------------------------------
    def refresh_tools(self, timeout=20):
        msg = self._request("tools/list", {}, timeout=timeout)
        if msg and "result" in msg:
            self.tools = msg["result"].get("tools", [])
        return self.tools

    @staticmethod
    def _is_transient(text):
        low = (text or "").lower()
        return any(h in low for h in TRANSIENT_DROP_HINTS)

    def call(self, name, arguments, timeout):
        """Returns {'text': str, 'images': [...]}. Raises on error/timeout."""
        timeout = max(1, min(int(timeout or DEFAULT_TIMEOUT), HARD_TIMEOUT_CAP))
        with self.call_lock:
            last_err = None
            for attempt in (1, 2):
                if not self.is_alive():
                    self._start_locked()
                msg = self._request("tools/call", {"name": name, "arguments": arguments},
                                    timeout)
                if msg is None:
                    if not self.is_alive():
                        self._start_locked()
                        msg = self._request("tools/call",
                                            {"name": name, "arguments": arguments}, timeout)
                    if msg is None:
                        raise TimeoutError(f"no response from StudioMCP after {timeout}s")
                if msg.get("error"):
                    err = msg["error"]
                    last_err = err.get("message", json.dumps(err))
                    if attempt == 1 and self._is_transient(last_err):
                        log(f"{name}: transient Studio drop, retrying once...", "~~")
                        time.sleep(1.5)
                        continue
                    raise RuntimeError(last_err)
                content = msg.get("result", {}).get("content", [])
                text = "\n".join(it.get("text", "") for it in content
                                 if it.get("type") == "text")
                images = [{"mime": it.get("mimeType", "image/jpeg"),
                           "data_b64": it["data"]}
                          for it in content
                          if it.get("type") == "image" and it.get("data")]
                if not text and not images and content:
                    text = json.dumps(content)[:4000]
                if attempt == 1 and self._is_transient(text):
                    log(f"{name}: transient Studio drop (in result), retrying once...", "~~")
                    time.sleep(1.5)
                    continue
                return {"text": text, "images": images}
            raise RuntimeError(last_err or "call failed after retry")


# ─────────────────────────────────────────────────────────────────────────────
# Tunnel manager (cloudflared quick tunnel; auto-download on Windows)
# ─────────────────────────────────────────────────────────────────────────────
CLOUDFLARED_DL = "https://github.com/cloudflare/cloudflared/releases/latest/download/"
# Real quick-tunnel URLs are random words (e.g. https://cat-dog-try.trycloudflare.com).
# 'api.' is Cloudflare's registration API host - it appears in error lines of FAILED
# registration attempts and must never be mistaken for the tunnel URL itself.
TUNNEL_URL_RE = re.compile(
    r"https://(?!api\.)(?!www\.)[a-z0-9][a-z0-9-]*\.trycloudflare\.com", re.I)


def _ensure_cloudflared():
    exe = shutil.which("cloudflared")
    if exe:
        return exe
    local = os.path.join(HERE, "cloudflared.exe" if sys.platform == "win32" else "cloudflared")
    if os.path.isfile(local):
        return local
    if sys.platform == "win32":
        url = CLOUDFLARED_DL + "cloudflared-windows-amd64.exe"
        log(f"downloading cloudflared ({url}) ...")
        tmp = local + ".part"
        with urlopen(url, timeout=180) as r, open(tmp, "wb") as f:
            while True:
                chunk = r.read(1 << 16)
                if not chunk:
                    break
                f.write(chunk)
        os.replace(tmp, local)
        log("cloudflared downloaded")
        return local
    raise RuntimeError(
        "cloudflared not found. Install it (brew install cloudflared) or place a "
        "'cloudflared' binary next to glmrelay.py, then re-run.")


def start_tunnel(port):
    exe = _ensure_cloudflared()
    base = [exe, "tunnel", "--url", f"http://localhost:{port}", "--no-autoupdate"]
    flags = 0x08000000 if sys.platform == "win32" else 0  # CREATE_NO_WINDOW
    state = {"proc": None, "url": None, "tail": deque(maxlen=12)}

    def pump(proc):
        for line in iter(proc.stdout.readline, ""):
            line = line.rstrip()
            if not line:
                continue
            state["tail"].append(line)
            low = line.lower()
            bad = ("err" in low) or ("failed" in low)
            m = TUNNEL_URL_RE.search(line)
            # only trust the URL on a healthy line from a live process
            if m and not state["url"] and not bad and proc.poll() is None:
                state["url"] = m.group(0)
                try:
                    with open(os.path.join(HERE, "tunnel_url.txt"), "w") as f:
                        f.write(state["url"] + "\n")
                except OSError:
                    pass
                log("=" * 66, "**")
                log("PUBLIC URL:  " + state["url"], "**")
                log("-> paste this URL into the chat. Keep this window open.", "**")
                log("=" * 66, "**")
            elif bad:
                log(f"tunnel: {line}", "!!")
            elif not state["url"]:
                log(f"tunnel: {line}", "..")
        log("tunnel process ended", "!!")

    def supervisor():
        restarts = 0
        while True:
            attempts = 0
            state["url"] = None
            while attempts < 3 and not state["url"]:
                attempts += 1
                # attempt 1 uses default QUIC; later attempts force HTTP/2 (TCP),
                # which survives networks/firewalls that block UDP.
                cmd = base + (["--protocol", "http2"] if attempts > 1 else [])
                proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                        text=True, encoding="utf-8", errors="replace",
                                        cwd=HERE, creationflags=flags)
                state["proc"] = proc
                log(f"tunnel: starting cloudflared (attempt {attempts}/3)...")
                threading.Thread(target=pump, args=(proc,), daemon=True).start()
                for _ in range(90):        # wait for URL or death, up to 90s per attempt
                    if state["url"] or proc.poll() is not None:
                        break
                    time.sleep(1)
                if state["url"]:
                    break
                if proc.poll() is None:
                    try:
                        proc.terminate()
                    except Exception:
                        pass
                if attempts < 3:
                    log(f"tunnel attempt {attempts} failed - retrying in 20s...", "!!")
                    time.sleep(20)
            if not state["url"]:
                log("tunnel could not be created. Last cloudflared output:", "!!")
                for l in list(state["tail"])[-8:]:
                    log(f"  | {l}", "!!")
                log("PLAN B: keep THIS window open, open a SECOND command window, cd into", "!!")
                log("the folder that holds glmrelay.py, then run:", "!!")
                log(f"    cloudflared.exe tunnel --url http://localhost:{port} --protocol http2", "!!")
                log("then copy the https://....trycloudflare.com URL it prints into the chat.", "!!")
                return
            # URL is live - watch the process; quick tunnels sometimes die -> restart
            proc = state["proc"]
            while proc.poll() is None:
                time.sleep(2)
            restarts += 1
            if restarts > 30:
                log("tunnel keeps dying - giving up. Re-run START_HERE.bat.", "!!")
                return
            log("tunnel died - restarting in 15s...", "!!")
            state["url"] = None
            try:
                os.remove(os.path.join(HERE, "tunnel_url.txt"))
            except OSError:
                pass
            time.sleep(15)

    threading.Thread(target=supervisor, daemon=True).start()
    return state


# ─────────────────────────────────────────────────────────────────────────────
# HTTP relay
# ─────────────────────────────────────────────────────────────────────────────
MCP = StudioMCP()
TUNNEL = {"proc": None, "url": None, "tail": deque(maxlen=12)}
STATS = {"calls": 0, "errors": 0, "started": time.strftime("%Y-%m-%d %H:%M:%S")}


def mcp_boot_loop():
    """Keep trying to bring the MCP link up; relay serves /status meanwhile."""
    while True:
        try:
            MCP.start()
            return
        except Exception as e:
            MCP.last_error = str(e)
            MCP.booted.clear()
            log(f"MCP start failed: {e} - retrying in 8s (is Studio open?)", "!!")
            time.sleep(8)


def status_snapshot():
    return {
        "ok": True,
        "name": "GlmBridge",
        "version": VERSION,
        "started": STATS["started"],
        "mcp": {
            "alive": MCP.is_alive(),
            "exe": MCP.exe_path,
            "tools": len(MCP.tools),
            "error": MCP.last_error,
            "stderr_tail": list(MCP.stderr_tail)[-3:],
        },
        "tunnel": {
            "running": TUNNEL["proc"] is not None and TUNNEL["proc"].poll() is None,
            "url": TUNNEL["url"],
        },
        "stats": {"calls": STATS["calls"], "errors": STATS["errors"]},
    }


STATUS_PAGE = """<!doctype html>
<html><head><meta charset="utf-8"><title>GlmBridge</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
 body{background:#0d1117;color:#e6edf3;font:15px/1.5 system-ui,sans-serif;margin:0;padding:2rem}
 .card{max-width:860px;margin:0 auto;background:#161b22;border:1px solid #30363d;border-radius:12px;padding:1.5rem 2rem}
 h1{margin:.2rem 0 0;font-size:1.5rem} h1 span{color:#3fb950}
 .row{display:flex;gap:.6rem;align-items:center;margin:.7rem 0;flex-wrap:wrap}
 .pill{background:#21262d;border:1px solid #30363d;border-radius:99px;padding:.15rem .8rem;font-size:.85rem}
 .ok{color:#3fb950}.bad{color:#f85149}.warn{color:#d29922}
 code,pre{background:#0d1117;border:1px solid #30363d;border-radius:6px;padding:.1rem .4rem}
 pre{padding:.8rem;overflow:auto;font-size:.82rem}
 table{border-collapse:collapse;width:100%;font-size:.85rem}
 td,th{border:1px solid #30363d;padding:.3rem .5rem;text-align:left}
</style></head><body><div class="card">
<h1>GlmBridge <span id="dot">...</span> <span class="pill">v__VER__</span></h1>
<div class="row" id="meta">loading...</div>
<h3>Tools live in your Studio</h3>
<div id="tools">loading...</div>
<h3>Use it from the agent</h3>
<pre>POST /call  {"tool":"execute_luau","arguments":{"code":"print(1+1)","datamodel_type":"Edit"},"timeout":30}</pre>
<p class="warn">No auth by owner's choice: anyone with this URL can run code in your Studio.
Keep the URL private and close this window (Ctrl+C) when done.</p>
</div>
<script>
async function j(u){const r=await fetch(u);return r.json()}
(async()=>{
 try{
  const s=await j('/status');
  const m=s.mcp;
  const dot=document.getElementById('dot');
  const meta=document.getElementById('meta');
  if(m.alive&&m.tools>0){dot.innerHTML='● connected';dot.className='ok'}
  else if(m.alive){dot.innerHTML='● mcp up, 0 tools';dot.className='warn'}
  else{dot.innerHTML='● studio offline';dot.className='bad'}
  meta.innerHTML=`<span class="pill">tools: ${m.tools}</span>`+
   `<span class="pill">tunnel: ${s.tunnel.running?('up '+(s.tunnel.url||'')):'down'}</span>`+
   `<span class="pill">calls: ${s.stats.calls}</span>`+
   (m.error?`<span class="bad">${m.error}</span>`:'');
  const t=await j('/tools');
  const rows=(t.tools||[]).map(x=>`<tr><td><code>${x.name}</code></td><td>${(x.description||'').replace(/</g,'&lt;').slice(0,120)}</td></tr>`).join('');
  document.getElementById('tools').innerHTML=rows?`<table><tr><th>tool</th><th>description</th></tr>${rows}</table>`:'(none)';
 }catch(e){document.getElementById('meta').textContent='error: '+e}
})();
</script></body></html>"""


class Handler(BaseHTTPRequestHandler):
    server_version = "GlmBridge/" + VERSION

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        if isinstance(body, bytes):
            data = body
        elif isinstance(body, str):
            data = body.encode()
        else:
            data = json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def log_message(self, fmt, *args):
        pass  # quiet; we do our own logging

    def do_OPTIONS(self):
        self._send(204, b"")

    def do_GET(self):
        path = urlsplit(self.path).path
        if path == "/":
            self._send(200, STATUS_PAGE.replace("__VER__", VERSION),
                       "text/html; charset=utf-8")
        elif path == "/status":
            self._send(200, status_snapshot())
        elif path == "/tools":
            tools = MCP.tools
            if MCP.is_alive() and not tools:
                try:
                    tools = MCP.refresh_tools(timeout=8)
                except Exception:
                    tools = MCP.tools
            self._send(200, {"ok": True, "tools": tools})
        elif path == "/favicon.ico":
            self._send(204, b"")
        else:
            self._send(404, {"ok": False, "error": f"unknown path {path}"})

    def do_POST(self):
        path = urlsplit(self.path).path
        if path != "/call":
            self._send(404, {"ok": False, "error": f"unknown path {path}"})
            return
        try:
            n = int(self.headers.get("Content-Length") or 0)
            if n > MAX_BODY:
                self._send(413, {"ok": False, "error": "body too large"})
                return
            body = json.loads(self.rfile.read(n) or b"{}")
        except Exception as e:
            self._send(400, {"ok": False, "error": f"bad JSON body: {e}"})
            return
        name = body.get("tool") or body.get("name")
        args = body.get("arguments")
        if args is None:
            args = body.get("params") or {}
        if not name or not isinstance(name, str):
            self._send(400, {"ok": False, "error": "missing 'tool' (string)"})
            return
        if not isinstance(args, dict):
            self._send(400, {"ok": False, "error": "'arguments' must be an object"})
            return
        if not MCP.booted.is_set() and not MCP.is_alive():
            self._send(503, {"ok": False,
                             "error": "MCP not connected yet: " + (MCP.last_error or "booting")})
            return
        t0 = time.time()
        STATS["calls"] += 1
        try:
            timeout = body.get("timeout", EXEC_LUAU_TIMEOUT if name == "execute_luau"
                               else DEFAULT_TIMEOUT)
            res = MCP.call(name, args, timeout)
            dur = time.time() - t0
            log(f"call {name} ok ({dur:.1f}s, {len(res['text'])} chars)")
            text = res["text"]
            truncated = False
            if len(text) > MAX_TEXT:
                text = text[:MAX_TEXT]
                truncated = True
            self._send(200, {"ok": True, "tool": name, "duration_s": round(dur, 2),
                             "text": text, "truncated": truncated,
                             "images": res["images"]})
        except Exception as e:
            STATS["errors"] += 1
            log(f"call {name} FAILED: {e}", "!!")
            self._send(200, {"ok": False, "tool": name,
                             "error": f"{type(e).__name__}: {e}"})


# ─────────────────────────────────────────────────────────────────────────────
def main():
    mode_tunnel = "--tunnel" in sys.argv
    print()
    log("╔════════════════════════════════════════════════════╗", "**")
    log(f"║  GlmBridge v{VERSION} - Roblox Studio relay             ║", "**")
    log("╚════════════════════════════════════════════════════╝", "**")
    log(f"relay: http://localhost:{RELAY_PORT}  (open in a browser for the status page)")
    if find_studio_mcp():
        log("StudioMCP.exe found - booting MCP link in background...")
    else:
        log("StudioMCP.exe NOT found yet - open Roblox Studio once; I keep retrying.", "!!")
    if mode_tunnel:
        try:
            TUNNEL.update(start_tunnel(RELAY_PORT))
        except Exception as e:
            log(f"tunnel failed to start: {e}", "!!")
            log("relay still runs locally - fix cloudflared and re-run with --tunnel", "!!")
    threading.Thread(target=mcp_boot_loop, daemon=True).start()
    httpd = ThreadingHTTPServer(("0.0.0.0", RELAY_PORT), Handler)
    httpd.daemon_threads = True
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        log("shutting down (Ctrl+C)")
        MCP.stop()


if __name__ == "__main__":
    main()
