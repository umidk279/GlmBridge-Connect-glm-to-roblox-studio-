#!/usr/bin/env python3
# glm_agent.py - GlmBridge client (the agent-side driver)
#
# This is the tool the AI agent runs inside its sandbox to drive YOUR Studio.
# It can also be used manually from any terminal:
#
#   python glm_agent.py status <BASE_URL>
#   python glm_agent.py tools  <BASE_URL> [name-filter]
#   python glm_agent.py call   <BASE_URL> <tool> [args-json] [timeout-sec]
#
# Examples:
#   python glm_agent.py status https://xxx.trycloudflare.com
#   python glm_agent.py tools  https://xxx.trycloudflare.com script
#   python glm_agent.py call   https://xxx.trycloudflare.com execute_luau \
#       '{"code":"print(workspace:GetFullName())","datamodel_type":"Edit"}' 30

import json
import sys
import time
import urllib.error
import urllib.request


def req(base, path, payload=None, timeout=330, retries=3):
    url = base.rstrip("/") + path
    if payload is None:
        r = urllib.request.Request(url)
    else:
        r = urllib.request.Request(
            url, data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json"})
    last = None
    for attempt in range(1, retries + 1):
        try:
            with urllib.request.urlopen(r, timeout=timeout) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            body = e.read().decode(errors="replace")
            try:
                return json.loads(body)
            except Exception:
                last = RuntimeError(f"HTTP {e.code}: {body[:300]}")
        except Exception as e:
            last = e
        # tunnels cold-start slowly; brief backoff then retry
        if attempt < retries:
            time.sleep(2 * attempt)
    raise last


def main(argv):
    if len(argv) < 3:
        print(__doc__)
        return 2
    cmd, base = argv[1], argv[2]

    if cmd == "status":
        print(json.dumps(req(base, "/status"), indent=2))
    elif cmd == "tools":
        flt = argv[3] if len(argv) > 3 else ""
        data = req(base, "/tools")
        tools = data.get("tools", [])
        if not tools:
            print("(no tools yet - Studio MCP not connected; see relay window)")
        for t in tools:
            if flt and flt.lower() not in t["name"].lower():
                continue
            print(f"- {t['name']}: {(t.get('description') or '').strip()[:160]}")
            schema = t.get("inputSchema") or {}
            props = schema.get("properties") or {}
            reqd = schema.get("required") or []
            for k, v in props.items():
                star = "*" if k in reqd else " "
                desc = (v.get("description") or v.get("type") or "")[:100]
                print(f"    {star}{k}: {desc}")
    elif cmd == "call":
        if len(argv) < 4:
            print("usage: glm_agent.py call <BASE_URL> <tool> [args-json] [timeout]")
            return 2
        tool = argv[3]
        args = json.loads(argv[4]) if len(argv) > 4 else {}
        timeout = int(argv[5]) if len(argv) > 5 else 120
        out = req(base, "/call",
                  {"tool": tool, "arguments": args, "timeout": timeout})
        print(json.dumps(out, indent=2)[:20000])
        return 0 if out.get("ok") else 1
    else:
        print(f"unknown command: {cmd}")
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
